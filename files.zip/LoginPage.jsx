// src/pages/LoginPage.jsx
// ─────────────────────────────────────────────────────────────
// Staff login screen — email + password via Supabase Auth
// ─────────────────────────────────────────────────────────────

import { useState } from 'react'
import { useAuth } from '../hooks/useAuth'

export default function LoginPage() {
  const { login } = useAuth()
  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')
  const [error, setError]       = useState('')
  const [loading, setLoading]   = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await login(email, password)
      // AuthProvider → onAuthStateChange → app re-renders to dashboard
    } catch (err) {
      setError(err.message || 'Login failed. Check your credentials.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #1a56db 0%, #0694a2 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <div style={{ background: '#fff', borderRadius: 20, padding: '40px 36px', width: '100%', maxWidth: 400 }}>
        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <div style={{ fontSize: 36 }}>⛪</div>
          <h1 style={{ fontSize: 22, fontWeight: 800, margin: '8px 0 4px', fontFamily: "'DM Sans', sans-serif" }}>ChurchReach</h1>
          <p style={{ color: '#6b7280', fontSize: 14 }}>Staff login</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, color: '#6b7280', display: 'block', marginBottom: 4 }}>Email</label>
            <input
              type="email" required value={email}
              onChange={e => setEmail(e.target.value)}
              style={{ width: '100%', padding: '10px 14px', border: '1.5px solid #e5e7eb', borderRadius: 8, fontSize: 14, boxSizing: 'border-box', fontFamily: "'DM Sans', sans-serif" }}
            />
          </div>
          <div style={{ marginBottom: 20 }}>
            <label style={{ fontSize: 12, color: '#6b7280', display: 'block', marginBottom: 4 }}>Password</label>
            <input
              type="password" required value={password}
              onChange={e => setPassword(e.target.value)}
              style={{ width: '100%', padding: '10px 14px', border: '1.5px solid #e5e7eb', borderRadius: 8, fontSize: 14, boxSizing: 'border-box', fontFamily: "'DM Sans', sans-serif" }}
            />
          </div>
          {error && <div style={{ background: '#fef2f2', color: '#991b1b', fontSize: 13, padding: '10px 14px', borderRadius: 8, marginBottom: 16 }}>{error}</div>}
          <button
            type="submit" disabled={loading}
            style={{ width: '100%', padding: 12, background: loading ? '#93c5fd' : '#1a56db', color: '#fff', border: 'none', borderRadius: 10, fontWeight: 700, fontSize: 15, cursor: loading ? 'not-allowed' : 'pointer', fontFamily: "'DM Sans', sans-serif" }}
          >
            {loading ? 'Signing in…' : 'Sign in'}
          </button>
        </form>
      </div>
    </div>
  )
}


// ─────────────────────────────────────────────────────────────
// src/App.jsx  — updated root with auth gate + Supabase hooks
// Replace the export default App in churchreach-app.jsx with:
// ─────────────────────────────────────────────────────────────

/*
import { AuthProvider, useAuth } from './hooks/useAuth'
import LoginPage from './pages/LoginPage'
import MainApp from './MainApp'   // rename the existing App component

function AppGate() {
  const { session, loading } = useAuth()
  if (loading) return <div style={{ display:'flex',alignItems:'center',justifyContent:'center',height:'100vh',fontSize:14,color:'#6b7280' }}>Loading…</div>
  return session ? <MainApp /> : <LoginPage />
}

export default function App() {
  return (
    <AuthProvider>
      <AppGate />
    </AuthProvider>
  )
}
*/


// ─────────────────────────────────────────────────────────────
// How to wire the existing components to real Supabase data
// ─────────────────────────────────────────────────────────────

/*
DASHBOARD — replace mock data with:

  import { useDashboardMetrics } from '../hooks/useAuth'
  const { metrics, loading } = useDashboardMetrics()
  // metrics.total, metrics.followUp, metrics.committed, metrics.fbLeads


VISITORS LIST — replace useState(INITIAL_VISITORS) with:

  import { useVisitors } from '../hooks/useAuth'
  const { visitors, loading, create, update } = useVisitors({ search, status: filter })
  // create(newVisitor)  — calls addVisitor() → Supabase insert
  // update(id, changes) — calls updateVisitor() → Supabase update


FOLLOW-UPS — replace local state with:

  import { useFollowUps } from '../hooks/useAuth'
  const { followUps, complete } = useFollowUps()
  // complete(id) marks done in Supabase, removes from list


CAMPAIGNS — replace CAMPAIGNS constant with:

  import { useCampaigns } from '../hooks/useAuth'
  const { campaigns } = useCampaigns()
  // reads from campaign_stats view — includes cost_per_lead, committed_count etc.


LANDING PAGE form submit — replace local handler with:

  import { submitVisitorForm } from '../lib/supabase'
  const utmCampaign = new URLSearchParams(window.location.search).get('utm_campaign')
  await submitVisitorForm({ churchSlug: 'grace-community', formData: form, utmCampaign })

  FB Ad URL format:
  https://yourapp.com/visit/grace-community?utm_campaign=easter-2026&utm_source=facebook
*/


// ─────────────────────────────────────────────────────────────
// .env.local  (never commit this file)
// ─────────────────────────────────────────────────────────────

/*
VITE_SUPABASE_URL=https://xxxxxxxxxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
*/


// ─────────────────────────────────────────────────────────────
// Setup checklist
// ─────────────────────────────────────────────────────────────

/*
1. Create project at https://supabase.com
2. Go to SQL Editor → paste and run schema.sql
3. Settings → API → copy URL + anon key into .env.local
4. npm install @supabase/supabase-js
5. Authentication → Email → enable "Confirm email" OFF for dev
6. Create your admin account via Supabase Dashboard → Auth → Add user
7. Run this in SQL Editor to link your auth user to a church:
      insert into public.users (id, church_id, full_name, role)
      values ('<your-auth-uid>', 'aaaaaaaa-0000-0000-0000-000000000001', 'Pastor James', 'admin');
8. Done — login at /login, add visitors, track follow-ups
*/
