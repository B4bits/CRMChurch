-- ============================================================
-- ChurchReach — Supabase Schema
-- Run this in your Supabase SQL editor (Dashboard → SQL Editor)
-- ============================================================

-- ── Extensions ───────────────────────────────────────────────
create extension if not exists "uuid-ossp";

-- ── 1. churches ──────────────────────────────────────────────
create table public.churches (
  id          uuid primary key default uuid_generate_v4(),
  name        text not null,
  slug        text not null unique,         -- used in landing page URL: /visit/{slug}
  logo_url    text,
  plan        text not null default 'free', -- free | pro | multi
  created_at  timestamptz not null default now()
);

-- ── 2. users (staff / admins per church) ─────────────────────
-- Supabase Auth handles authentication; this table stores profile + role
create table public.users (
  id          uuid primary key references auth.users(id) on delete cascade,
  church_id   uuid not null references public.churches(id) on delete cascade,
  full_name   text not null,
  role        text not null default 'staff', -- admin | staff | volunteer
  created_at  timestamptz not null default now()
);

-- ── 3. campaigns ─────────────────────────────────────────────
create table public.campaigns (
  id          uuid primary key default uuid_generate_v4(),
  church_id   uuid not null references public.churches(id) on delete cascade,
  name        text not null,
  platform    text not null default 'facebook', -- facebook | instagram | other
  utm_tag     text,                              -- matches ?utm_campaign= on landing page
  budget      numeric(10,2) default 0,
  status      text not null default 'active',   -- active | paused | ended
  created_at  timestamptz not null default now()
);

-- ── 4. visitors ──────────────────────────────────────────────
create table public.visitors (
  id            uuid primary key default uuid_generate_v4(),
  church_id     uuid not null references public.churches(id) on delete cascade,
  campaign_id   uuid references public.campaigns(id) on delete set null,
  full_name     text not null,
  phone         text,
  email         text,
  source        text not null default 'walk-in', -- facebook | instagram | referral | walk-in | other
  status        text not null default 'new',      -- new | follow-up | returning | committed | no-response
  visited       boolean not null default false,
  visit_date    date not null default current_date,
  notes         text,
  assigned_to   uuid references public.users(id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- ── 5. follow_ups ────────────────────────────────────────────
create table public.follow_ups (
  id          uuid primary key default uuid_generate_v4(),
  visitor_id  uuid not null references public.visitors(id) on delete cascade,
  church_id   uuid not null references public.churches(id) on delete cascade,
  assigned_to uuid references public.users(id) on delete set null,
  due_date    date not null,
  method      text not null default 'call',       -- call | whatsapp | email | visit
  status      text not null default 'pending',    -- pending | done | skipped
  notes       text,
  created_at  timestamptz not null default now(),
  completed_at timestamptz
);

-- ── 6. activity_log ──────────────────────────────────────────
create table public.activity_log (
  id          uuid primary key default uuid_generate_v4(),
  visitor_id  uuid not null references public.visitors(id) on delete cascade,
  church_id   uuid not null references public.churches(id) on delete cascade,
  user_id     uuid references public.users(id) on delete set null,
  type        text not null, -- 'note' | 'call' | 'whatsapp' | 'status_change' | 'visit'
  content     text,
  created_at  timestamptz not null default now()
);

-- ============================================================
-- Row Level Security (RLS)
-- Every table is locked to church_id — staff can only see
-- their own church's data, even if they guess a UUID.
-- ============================================================

alter table public.churches    enable row level security;
alter table public.users       enable row level security;
alter table public.campaigns   enable row level security;
alter table public.visitors    enable row level security;
alter table public.follow_ups  enable row level security;
alter table public.activity_log enable row level security;

-- Helper: get the church_id of the currently logged-in user
create or replace function public.my_church_id()
returns uuid language sql stable security definer as $$
  select church_id from public.users where id = auth.uid()
$$;

-- churches: staff can read their own church row only
create policy "church members can view own church"
  on public.churches for select
  using (id = public.my_church_id());

-- users: can view teammates in same church
create policy "view teammates"
  on public.users for select
  using (church_id = public.my_church_id());

-- campaigns
create policy "campaigns: church only"
  on public.campaigns for all
  using (church_id = public.my_church_id());

-- visitors: full CRUD for own church
create policy "visitors: church only"
  on public.visitors for all
  using (church_id = public.my_church_id());

-- follow_ups
create policy "follow_ups: church only"
  on public.follow_ups for all
  using (church_id = public.my_church_id());

-- activity_log
create policy "activity: church only"
  on public.activity_log for all
  using (church_id = public.my_church_id());

-- ============================================================
-- Public landing page insert (no auth required)
-- Visitors submit the form anonymously → INSERT only, no read
-- ============================================================
create policy "public can insert visitors"
  on public.visitors for insert
  with check (true);  -- church_id is set server-side via slug lookup

-- ============================================================
-- Auto-update updated_at on visitors
-- ============================================================
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger visitors_updated_at
  before update on public.visitors
  for each row execute function public.set_updated_at();

-- ============================================================
-- Useful views
-- ============================================================

-- Dashboard summary per campaign
create or replace view public.campaign_stats as
select
  c.id,
  c.church_id,
  c.name,
  c.platform,
  c.budget,
  c.status,
  c.utm_tag,
  count(v.id)                                        as total_leads,
  count(v.id) filter (where v.visited = true)        as visited_count,
  count(v.id) filter (where v.status = 'committed')  as committed_count,
  case when count(v.id) > 0
    then round(c.budget / count(v.id), 2) end        as cost_per_lead,
  case when count(v.id) filter (where v.status = 'committed') > 0
    then round(c.budget / count(v.id) filter (where v.status = 'committed'), 2)
  end                                                as cost_per_committed
from public.campaigns c
left join public.visitors v
  on v.campaign_id = c.id and v.church_id = c.church_id
group by c.id;

-- ============================================================
-- Seed data — replace with your real church details
-- ============================================================

-- 1. Insert your church
insert into public.churches (id, name, slug, plan)
values (
  'aaaaaaaa-0000-0000-0000-000000000001',
  'Grace Community Church',
  'grace-community',
  'pro'
);

-- 2. After signing up via Supabase Auth, insert your user profile:
-- insert into public.users (id, church_id, full_name, role)
-- values (auth.uid(), 'aaaaaaaa-0000-0000-0000-000000000001', 'Pastor James', 'admin');

-- 3. Sample campaign
insert into public.campaigns (church_id, name, platform, utm_tag, budget, status)
values
  ('aaaaaaaa-0000-0000-0000-000000000001', 'Easter 2026',    'facebook',  'easter-2026',    5000, 'active'),
  ('aaaaaaaa-0000-0000-0000-000000000001', 'Sunday Service', 'facebook',  'sunday-service', 2000, 'active'),
  ('aaaaaaaa-0000-0000-0000-000000000001', 'Youth Event',    'facebook',  'youth-event',    1500, 'paused');
