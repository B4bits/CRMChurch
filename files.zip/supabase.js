// src/lib/supabase.js
// ─────────────────────────────────────────────────────────────
// Install:  npm install @supabase/supabase-js
// Env vars: VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY
//           (copy from Supabase Dashboard → Settings → API)
// ─────────────────────────────────────────────────────────────

import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL  = import.meta.env.VITE_SUPABASE_URL
const SUPABASE_ANON = import.meta.env.VITE_SUPABASE_ANON_KEY

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON)

// ─── AUTH ─────────────────────────────────────────────────────

export async function signIn(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) throw error
  return data
}

export async function signOut() {
  const { error } = await supabase.auth.signOut()
  if (error) throw error
}

export async function getSession() {
  const { data: { session } } = await supabase.auth.getSession()
  return session
}

// Get logged-in user's profile (church_id, role, etc.)
export async function getMyProfile() {
  const { data, error } = await supabase
    .from('users')
    .select('*, churches(*)')
    .single()
  if (error) throw error
  return data  // { id, church_id, full_name, role, churches: { name, slug, ... } }
}

// ─── CHURCH ───────────────────────────────────────────────────

// Lookup church by slug (used by public landing page — no auth needed)
export async function getChurchBySlug(slug) {
  const { data, error } = await supabase
    .from('churches')
    .select('id, name, slug, logo_url')
    .eq('slug', slug)
    .single()
  if (error) throw error
  return data
}

// ─── VISITORS ─────────────────────────────────────────────────

// Fetch all visitors for the logged-in user's church
export async function getVisitors({ status, search, orderBy = 'created_at', ascending = false } = {}) {
  let query = supabase
    .from('visitors')
    .select(`
      *,
      campaigns(name, platform),
      assigned_user:users!visitors_assigned_to_fkey(id, full_name)
    `)
    .order(orderBy, { ascending })

  if (status && status !== 'all') query = query.eq('status', status)
  if (search) {
    query = query.or(`full_name.ilike.%${search}%,phone.ilike.%${search}%,email.ilike.%${search}%`)
  }

  const { data, error } = await query
  if (error) throw error
  return data
}

// Get a single visitor with all related data
export async function getVisitor(id) {
  const { data, error } = await supabase
    .from('visitors')
    .select(`
      *,
      campaigns(id, name, platform),
      assigned_user:users!visitors_assigned_to_fkey(id, full_name),
      follow_ups(*, assigned_user:users!follow_ups_assigned_to_fkey(id, full_name)),
      activity_log(*, actor:users!activity_log_user_id_fkey(id, full_name))
    `)
    .eq('id', id)
    .order('created_at', { ascending: false, foreignTable: 'activity_log' })
    .single()
  if (error) throw error
  return data
}

// Add a new visitor (called from dashboard when staff add manually)
export async function addVisitor(visitor) {
  const profile = await getMyProfile()
  const { data, error } = await supabase
    .from('visitors')
    .insert({ ...visitor, church_id: profile.church_id })
    .select()
    .single()
  if (error) throw error
  return data
}

// Update visitor fields
export async function updateVisitor(id, updates) {
  const { data, error } = await supabase
    .from('visitors')
    .update(updates)
    .eq('id', id)
    .select()
    .single()
  if (error) throw error
  return data
}

// ─── PUBLIC LANDING PAGE FORM SUBMIT (no auth) ────────────────
// The slug identifies the church; campaign matched by utm_tag
export async function submitVisitorForm({ churchSlug, formData, utmCampaign }) {
  // 1. Lookup church
  const church = await getChurchBySlug(churchSlug)

  // 2. Try to match utm_campaign tag to a campaign row
  let campaignId = null
  if (utmCampaign) {
    const { data: camp } = await supabase
      .from('campaigns')
      .select('id')
      .eq('church_id', church.id)
      .eq('utm_tag', utmCampaign)
      .maybeSingle()
    campaignId = camp?.id ?? null
  }

  // 3. Insert visitor (public policy allows anonymous insert)
  const { data, error } = await supabase
    .from('visitors')
    .insert({
      church_id:    church.id,
      campaign_id:  campaignId,
      full_name:    formData.name,
      phone:        formData.phone,
      email:        formData.email || null,
      source:       formData.source || 'facebook',
      status:       'new',
      visit_date:   new Date().toISOString().slice(0, 10),
    })
    .select('id')
    .single()

  if (error) throw error
  return data
}

// ─── FOLLOW-UPS ───────────────────────────────────────────────

export async function getFollowUps({ status } = {}) {
  let query = supabase
    .from('follow_ups')
    .select(`
      *,
      visitors(id, full_name, phone, email, source, status),
      assigned_user:users!follow_ups_assigned_to_fkey(id, full_name)
    `)
    .order('due_date', { ascending: true })

  if (status) query = query.eq('status', status)

  const { data, error } = await query
  if (error) throw error
  return data
}

export async function addFollowUp(followUp) {
  const profile = await getMyProfile()
  const { data, error } = await supabase
    .from('follow_ups')
    .insert({ ...followUp, church_id: profile.church_id })
    .select()
    .single()
  if (error) throw error
  return data
}

export async function completeFollowUp(id) {
  const { data, error } = await supabase
    .from('follow_ups')
    .update({ status: 'done', completed_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single()
  if (error) throw error
  return data
}

// ─── CAMPAIGNS ────────────────────────────────────────────────

export async function getCampaignStats() {
  // Uses the campaign_stats view defined in schema.sql
  const profile = await getMyProfile()
  const { data, error } = await supabase
    .from('campaign_stats')
    .select('*')
    .eq('church_id', profile.church_id)
    .order('total_leads', { ascending: false })
  if (error) throw error
  return data
}

export async function addCampaign(campaign) {
  const profile = await getMyProfile()
  const { data, error } = await supabase
    .from('campaigns')
    .insert({ ...campaign, church_id: profile.church_id })
    .select()
    .single()
  if (error) throw error
  return data
}

// ─── ACTIVITY LOG ─────────────────────────────────────────────

export async function logActivity(visitorId, type, content = '') {
  const profile = await getMyProfile()
  const { error } = await supabase
    .from('activity_log')
    .insert({
      visitor_id: visitorId,
      church_id:  profile.church_id,
      user_id:    profile.id,
      type,
      content,
    })
  if (error) throw error
}

// ─── DASHBOARD METRICS ────────────────────────────────────────

export async function getDashboardMetrics() {
  // Run a single aggregation query instead of multiple round-trips
  const { data: visitors, error } = await supabase
    .from('visitors')
    .select('status, source, visited, created_at')

  if (error) throw error

  const today = new Date().toISOString().slice(0, 10)
  const weekAgo = new Date(Date.now() - 7 * 86400000).toISOString().slice(0, 10)

  return {
    total:       visitors.length,
    newThisWeek: visitors.filter(v => v.created_at.slice(0, 10) >= weekAgo).length,
    followUp:    visitors.filter(v => v.status === 'follow-up').length,
    committed:   visitors.filter(v => v.status === 'committed').length,
    fbLeads:     visitors.filter(v => v.source === 'facebook' || v.source === 'instagram').length,
    byStatus: {
      new:          visitors.filter(v => v.status === 'new').length,
      'follow-up':  visitors.filter(v => v.status === 'follow-up').length,
      returning:    visitors.filter(v => v.status === 'returning').length,
      committed:    visitors.filter(v => v.status === 'committed').length,
      'no-response':visitors.filter(v => v.status === 'no-response').length,
    },
    bySource: {
      facebook:  visitors.filter(v => v.source === 'facebook').length,
      instagram: visitors.filter(v => v.source === 'instagram').length,
      referral:  visitors.filter(v => v.source === 'referral').length,
      'walk-in': visitors.filter(v => v.source === 'walk-in').length,
    }
  }
}
