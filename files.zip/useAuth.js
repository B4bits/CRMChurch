// src/hooks/useAuth.js
// ─────────────────────────────────────────────────────────────
// Wrap your app in <AuthProvider> then call useAuth() anywhere
// ─────────────────────────────────────────────────────────────

import { createContext, useContext, useEffect, useState } from 'react'
import { supabase, getMyProfile, signIn, signOut } from '../lib/supabase'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [session, setSession]   = useState(null)
  const [profile, setProfile]   = useState(null)   // { id, full_name, role, church_id, churches }
  const [loading, setLoading]   = useState(true)

  useEffect(() => {
    // Hydrate session on first load
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      if (session) loadProfile()
      else setLoading(false)
    })

    // Listen for login / logout
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session)
      if (session) loadProfile()
      else { setProfile(null); setLoading(false) }
    })

    return () => subscription.unsubscribe()
  }, [])

  async function loadProfile() {
    try {
      const p = await getMyProfile()
      setProfile(p)
    } catch (e) {
      console.error('Profile load failed', e)
    } finally {
      setLoading(false)
    }
  }

  async function login(email, password) {
    await signIn(email, password)
    // onAuthStateChange above triggers loadProfile
  }

  async function logout() {
    await signOut()
  }

  return (
    <AuthContext.Provider value={{ session, profile, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>')
  return ctx
}


// ─────────────────────────────────────────────────────────────
// src/hooks/useVisitors.js — data hooks with real-time updates
// ─────────────────────────────────────────────────────────────

import { useEffect, useState, useCallback } from 'react'
import {
  getVisitors, addVisitor, updateVisitor,
  getFollowUps, addFollowUp, completeFollowUp,
  getCampaignStats, getDashboardMetrics,
  logActivity,
} from '../lib/supabase'

// Visitors list with live subscription
export function useVisitors(filters = {}) {
  const [visitors, setVisitors] = useState([])
  const [loading, setLoading]   = useState(true)
  const [error, setError]       = useState(null)

  const fetch = useCallback(async () => {
    try {
      setLoading(true)
      const data = await getVisitors(filters)
      setVisitors(data)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [JSON.stringify(filters)])

  useEffect(() => {
    fetch()

    // Real-time: re-fetch when any visitor row changes in this church
    const channel = supabase
      .channel('visitors-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'visitors' }, fetch)
      .subscribe()

    return () => supabase.removeChannel(channel)
  }, [fetch])

  const create = async (visitor) => {
    const created = await addVisitor(visitor)
    setVisitors(vs => [created, ...vs])
    return created
  }

  const update = async (id, updates) => {
    const updated = await updateVisitor(id, updates)
    setVisitors(vs => vs.map(v => v.id === id ? updated : v))
    return updated
  }

  return { visitors, loading, error, refetch: fetch, create, update }
}

// Follow-ups hook
export function useFollowUps() {
  const [followUps, setFollowUps] = useState([])
  const [loading, setLoading]     = useState(true)

  useEffect(() => {
    getFollowUps({ status: 'pending' })
      .then(setFollowUps)
      .finally(() => setLoading(false))
  }, [])

  const complete = async (id) => {
    await completeFollowUp(id)
    setFollowUps(fus => fus.filter(f => f.id !== id))
  }

  const add = async (followUp) => {
    const created = await addFollowUp(followUp)
    setFollowUps(fus => [...fus, created])
    return created
  }

  return { followUps, loading, complete, add }
}

// Dashboard metrics hook
export function useDashboardMetrics() {
  const [metrics, setMetrics] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getDashboardMetrics()
      .then(setMetrics)
      .finally(() => setLoading(false))
  }, [])

  return { metrics, loading }
}

// Campaign stats hook
export function useCampaigns() {
  const [campaigns, setCampaigns] = useState([])
  const [loading, setLoading]     = useState(true)

  useEffect(() => {
    getCampaignStats()
      .then(setCampaigns)
      .finally(() => setLoading(false))
  }, [])

  return { campaigns, loading }
}
